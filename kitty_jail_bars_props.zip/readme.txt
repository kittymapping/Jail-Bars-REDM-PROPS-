Kitty Jail Bars Props | REDM

This package features custom made jail bars and windows.

Jail bars: 16
Jail windows: 4

Number of props: 20

Installation for the props: 
	      1. Unzip the file and drag into your resources.
	      2. Ensure the resource.

Each of the props can be placed with Spooner.
1. Open Spooner
2. Go to Objects
3. Type the correct name of the prop
4. Go to "Spawn by name"
5. Press "E" on your keyboard
